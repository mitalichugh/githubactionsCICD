def add(a, b):
    return a + b

if __name__ == "__main__":
    print("Sum:", add(2, 3))
